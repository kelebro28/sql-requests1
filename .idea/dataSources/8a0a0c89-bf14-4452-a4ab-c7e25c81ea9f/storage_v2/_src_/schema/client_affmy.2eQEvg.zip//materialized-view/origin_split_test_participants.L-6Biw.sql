CREATE MATERIALIZED VIEW client_affmy.origin_split_test_participants
            (`event_date` Date, `timestamp` Int32, `test_id` Int32, `variant_id` Int32, `item_type` String,
             `item_id` String,
             `is_deleted` UInt8) ENGINE = MergeTree() PARTITION BY toYYYYMM(event_date) ORDER BY timestamp SETTINGS index_granularity = 8192
AS
SELECT *
FROM globica.origin_split_test_participants
WHERE dictGetString('split_tests', 'name', tuple(toUInt32(test_id))) LIKE 'AFFMY:%';

